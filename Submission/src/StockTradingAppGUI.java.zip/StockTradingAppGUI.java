import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class StockTradingAppGUI extends JFrame {

  private JPasswordField pfield;
  private JButton pButton;
  private JLabel pDisplay;

  private JLabel checkboxDisplay;
  private JLabel radioDisplay;
  private JLabel comboboxDisplay;
  private JLabel colorChooserDisplay;
  private JLabel fileOpenDisplay;
  private JLabel fileSaveDisplay;
  private JLabel inputDisplay;
  private JLabel optionDisplay;

  private JList<String> listOfStrings;
  private JList<Integer> listOfIntegers;

  public StockTradingAppGUI() {
    setTitle("Stock Trading Application");
    setSize(800, 900);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);

    // Main panel to hold the components
    JPanel mainPanel = new JPanel();
    mainPanel.setLayout(new BorderLayout(10, 10));

    // Title label
    JLabel titleLabel = new JLabel("Stock Simulation", SwingConstants.CENTER);
    titleLabel.setFont(new Font("Serif", Font.BOLD, 24));
    mainPanel.add(titleLabel, BorderLayout.NORTH);

    // Panel to hold buttons
    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new GridLayout(14, 1, 10, 10));

    // Create buttons for each option
    String[] options = {
            "View Stock Gain/Loss",
            "View x-Day Moving Average",
            "View x-Day Crossovers",
            "Create Portfolio",
            "View Portfolio Value",
            "Add Stock",
            "Remove Stock",
            "View Portfolio Value Distribution",
            "Determine Portfolio Composition on Date",
            "Rebalance Portfolio",
            "Clear Portfolio",
            "View Portfolio Performance Over Time",
            "Update Portfolio",
            "Exit"
    };

    for (String option : options) {
      JButton button = new JButton(option);
      button.addActionListener(new MenuButtonListener());
      buttonPanel.add(button);
    }

    // Add the button panel to the main panel
    mainPanel.add(buttonPanel, BorderLayout.WEST);

    // Load the image
    ImageIcon imageIcon = new ImageIcon("/Users/justinliu/Documents/ood/Final_Assignment/Submission/stock.png\n");
    JLabel imageLabel = new JLabel(imageIcon);
    imageLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 5));

    // Add the image label to the main panel at the top right
    JPanel topPanel = new JPanel(new BorderLayout());
    topPanel.add(titleLabel, BorderLayout.CENTER);
    topPanel.add(imageLabel, BorderLayout.EAST);
    mainPanel.add(topPanel, BorderLayout.NORTH);

    // Additional features panel
    JPanel featuresPanel = new JPanel();
    featuresPanel.setLayout(new BoxLayout(featuresPanel, BoxLayout.PAGE_AXIS));

    // Combo boxes
    JPanel comboboxPanel = new JPanel();
    comboboxPanel.setBorder(BorderFactory.createTitledBorder("Combo boxes"));
    comboboxPanel.setLayout(new BoxLayout(comboboxPanel, BoxLayout.PAGE_AXIS));
    comboboxDisplay = new JLabel("Cold Stone Creamery: Which size do you want?");
    comboboxPanel.add(comboboxDisplay);
    String[] comboBoxOptions = {"Like it", "Love it", "Gotta have it"};
    JComboBox<String> combobox = new JComboBox<>(comboBoxOptions);
    combobox.setActionCommand("Size options");
    combobox.addActionListener(e -> comboboxDisplay.setText("You selected: " + combobox.getSelectedItem()));
    comboboxPanel.add(combobox);
    featuresPanel.add(comboboxPanel);

    // Dialog boxes
    JPanel dialogBoxesPanel = new JPanel();
    dialogBoxesPanel.setBorder(BorderFactory.createTitledBorder("Dialog boxes"));
    dialogBoxesPanel.setLayout(new BoxLayout(dialogBoxesPanel, BoxLayout.PAGE_AXIS));

    // Message dialog
    JPanel messageDialogPanel = new JPanel(new FlowLayout());
    JButton messageButton = new JButton("Click for a message");
    messageButton.setActionCommand("Message");
    messageButton.addActionListener(e -> showMessageDialog());
    messageDialogPanel.add(messageButton);
    dialogBoxesPanel.add(messageDialogPanel);

    // Input dialog
    JPanel inputDialogPanel = new JPanel(new FlowLayout());
    JButton inputButton = new JButton("Click to enter username");
    inputButton.setActionCommand("Input");
    inputButton.addActionListener(e -> inputDisplay.setText(JOptionPane.showInputDialog("Please enter your username")));
    inputDialogPanel.add(inputButton);
    inputDisplay = new JLabel("Default");
    inputDialogPanel.add(inputDisplay);
    dialogBoxesPanel.add(inputDialogPanel);

    // Options dialog
    JPanel optionsDialogPanel = new JPanel(new FlowLayout());
    JButton optionButton = new JButton("Click to enter options");
    optionButton.setActionCommand("Option");
    optionButton.addActionListener(e -> showOptionsDialog());
    optionsDialogPanel.add(optionButton);
    optionDisplay = new JLabel("Default");
    optionsDialogPanel.add(optionDisplay);
    dialogBoxesPanel.add(optionsDialogPanel);

    featuresPanel.add(dialogBoxesPanel);

    // Add features panel to main panel
    mainPanel.add(new JScrollPane(featuresPanel), BorderLayout.CENTER);

    // Add the main panel to the frame
    add(mainPanel);
  }

  private class MenuButtonListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      JButton source = (JButton) e.getSource();
      String actionCommand = source.getText();

      switch (actionCommand) {
        case "View Stock Gain/Loss":
          // Add your action here
          JOptionPane.showMessageDialog(null, "View Stock Gain/Loss Clicked");
          break;
        case "View x-Day Moving Average":
          // Add your action here
          JOptionPane.showMessageDialog(null, "View x-Day Moving Average Clicked");
          break;
        case "View x-Day Crossovers":
          // Add your action here
          JOptionPane.showMessageDialog(null, "View x-Day Crossovers Clicked");
          break;
        case "Create Portfolio":
          // Add your action here
          JOptionPane.showMessageDialog(null, "Create Portfolio Clicked");
          break;
        case "View Portfolio Value":
          // Add your action here
          JOptionPane.showMessageDialog(null, "View Portfolio Value Clicked");
          break;
        case "Add Stock":
          // Add your action here
          JOptionPane.showMessageDialog(null, "Add Stock Clicked");
          break;
        case "Remove Stock":
          // Add your action here
          JOptionPane.showMessageDialog(null, "Remove Stock Clicked");
          break;
        case "View Portfolio Value Distribution":
          // Add your action here
          JOptionPane.showMessageDialog(null, "View Portfolio Value Distribution Clicked");
          break;
        case "Determine Portfolio Composition on Date":
          // Add your action here
          JOptionPane.showMessageDialog(null, "Determine Portfolio Composition on Date Clicked");
          break;
        case "Rebalance Portfolio":
          // Add your action here
          JOptionPane.showMessageDialog(null, "Rebalance Portfolio Clicked");
          break;
        case "Clear Portfolio":
          // Add your action here
          JOptionPane.showMessageDialog(null, "Clear Portfolio Clicked");
          break;
        case "View Portfolio Performance Over Time":
          // Add your action here
          JOptionPane.showMessageDialog(null, "View Portfolio Performance Over Time Clicked");
          break;
        case "Update Portfolio":
          // Add your action here
          JOptionPane.showMessageDialog(null, "Update Portfolio Clicked");
          break;
        case "Exit":
          // Add your action here
          JOptionPane.showMessageDialog(null, "Exiting...");
          System.exit(0);
          break;
        default:
          JOptionPane.showMessageDialog(null, "Invalid Option");
          break;
      }
    }
  }

  private void radioButtonActionPerformed(ActionEvent e) {
    radioDisplay.setText("Radio button " + e.getActionCommand().substring(2) + " was selected");
  }

  private void showListSelection(ListSelectionEvent e, JList<?> list) {
    if (!e.getValueIsAdjusting()) {
      JOptionPane.showMessageDialog(this, "Selected: " + list.getSelectedValue());
    }
  }

  private void colorChooserActionPerformed() {
    Color col = JColorChooser.showDialog(this, "Choose a color", colorChooserDisplay.getBackground());
    if (col != null) {
      colorChooserDisplay.setBackground(col);
    }
  }

  private void fileOpenActionPerformed() {
    JFileChooser fileChooser = new JFileChooser(".");
    FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & GIF Images", "jpg", "gif");
    fileChooser.setFileFilter(filter);
    int retvalue = fileChooser.showOpenDialog(this);
    if (retvalue == JFileChooser.APPROVE_OPTION) {
      File file = fileChooser.getSelectedFile();
      fileOpenDisplay.setText(file.getAbsolutePath());
    }
  }

  private void fileSaveActionPerformed() {
    JFileChooser fileChooser = new JFileChooser(".");
    int retvalue = fileChooser.showSaveDialog(this);
    if (retvalue == JFileChooser.APPROVE_OPTION) {
      File file = fileChooser.getSelectedFile();
      fileSaveDisplay.setText(file.getAbsolutePath());
    }
  }

  private void showMessageDialog() {
    JOptionPane.showMessageDialog(this, "This is a demo message", "Message", JOptionPane.PLAIN_MESSAGE);
    JOptionPane.showMessageDialog(this, "You are about to be deleted.", "Last Chance", JOptionPane.WARNING_MESSAGE);
    JOptionPane.showMessageDialog(this, "You have been deleted.", "Too late", JOptionPane.ERROR_MESSAGE);
    JOptionPane.showMessageDialog(this, "Please start again.", "What to do next", JOptionPane.INFORMATION_MESSAGE);
  }

  private void showOptionsDialog() {
    String[] options = {"Uno", "Dos", "Tres", "Cuatro", "Cinco", "seis", "siete", "ocho", "nueve", "diez"};
    int retvalue = JOptionPane.showOptionDialog(this, "Please choose number", "Options", JOptionPane.YES_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[4]);
    optionDisplay.setText(options[retvalue]);
  }

  public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> {
      new StockTradingAppGUI().setVisible(true);
    });
  }
}
